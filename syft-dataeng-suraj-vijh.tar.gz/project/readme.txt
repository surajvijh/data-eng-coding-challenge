How to run code
Prerequsite: Spark, Maven Installation is required

--Build code using mvn clean install
--cd target
--unzip project.zip
--cd project/scripts
--sh run-app.sh
--cat ../result.csv  (This is where continuity evaluation result will be present.)


If you were to review someone else's code, what would you pay attention to?
A. Whether Logic to evaluate continuity will work for different scenarios or not.
    Code readability
    Duplicacy in code
    Defined constants properly or not
    How  easily to do enhancement of code
    Will there be any performance bottleneck with code?

We provided a CSV file for conveniency, but in a production environment, what format or database would you recommend instead for this use-case (and why)?
A. Good to have file format in parquet or orc format in HDFS/ cloud storage, so that parallelism can be achieved while reading.
External table reading data from parquet file can be used to generate report.
If using cloud, bigquery/redshift or any MPP database can be used as a target to generate report

Is there anything else you would implement differently for a large-scale application in production?
Refer Real_time_architecture.png. I have created a separate design for this usecase.