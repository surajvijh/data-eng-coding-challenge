package com.company.logic

import com.company.core.SparkUtil
import com.company.entity.{Constants, SourceSchema}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.scalatest.{BeforeAndAfterAll, FunSuite}

class WorkerContinuityLogicTest extends FunSuite with BeforeAndAfterAll {


    @transient var spark: SparkSession = _
    var sourceDF: DataFrame = _
    val workerContinuityLogicTest:WorkerContinuityCalculatorLogic= new WorkerContinuityCalculatorLogic

    override def beforeAll(): Unit = {
      spark = SparkUtil.getSparkSession("local")

      val list=List(

//        Scenario with same job, same role but without intermittent break
        SourceSchema("W1","E1","R1","2021-01-01 00:00:00"),
        SourceSchema("W1","E1","R1","2021-01-02 00:00:00"),
        SourceSchema("W1","E1","R1","2021-01-03 00:00:00"),

        SourceSchema("W3","E1","R1","2021-01-09 00:00:00"),

//        Scenario with same job, same role but with one break
        SourceSchema("W2","E1","R1","2021-01-01 00:00:00"),
        SourceSchema("W2","E1","R1","2021-01-08 00:00:00"),
        SourceSchema("W2","E1","R1","2021-01-09 00:00:00"),

//        Scenario with same job, same role but with intermittent break of more than 6 days
        SourceSchema("W4","E1","R1","2021-01-01 00:00:00"),
        SourceSchema("W4","E1","R1","2021-01-08 00:00:00"),
        SourceSchema("W4","E1","R1","2021-01-15 00:00:00"),

//        Scenario with same job, same role but with intermittent break
        SourceSchema("W5","E1","R1","2021-01-01 00:00:00"),
        SourceSchema("W5","E1","R1","2021-01-08 00:00:00"),
        SourceSchema("W5","E1","R1","2021-01-09 00:00:00"),
        SourceSchema("W5","E1","R1","2021-01-10 00:00:00"),
        SourceSchema("W5","E1","R1","2021-02-10 00:00:00"),
        SourceSchema("W5","E1","R1","2021-03-10 00:00:00"),
        SourceSchema("W5","E1","R1","2021-03-11 00:00:00"),
        SourceSchema("W5","E1","R1","2021-03-12 00:00:00"),

//        Scenario with different job, same role and no break
        SourceSchema("W6","E1","R1","2021-03-10 00:00:00"),
        SourceSchema("W6","E2","R1","2021-03-11 00:00:00"),
        SourceSchema("W6","E2","R1","2021-03-12 00:00:00"),

//        Scenario with same job, different role and no break
        SourceSchema("W7","E2","R1","2021-03-10 00:00:00"),
        SourceSchema("W7","E2","R1","2021-03-11 00:00:00"),
        SourceSchema("W7","E2","R2","2021-03-12 00:00:00"),

//        Scenario with changed job and also break in between
        SourceSchema("W8","E1","R1","2020-02-02 05:00:00"),
        SourceSchema("W8","E1","R1","2020-02-03 05:00:00"),
        SourceSchema("W8","E1","R1","2020-11-27 05:00:00"),
        SourceSchema("W8","E1","R2","2020-11-28 05:00:00"),
        SourceSchema("W8","E1","R1","2020-11-29 14:30:00")
      )
       sourceDF=spark.createDataFrame(list).toDF(Constants.COL_WORKER, Constants.COL_EMPLOYER,Constants.COL_ROLE,Constants.COL_DATE)
    }

    override def afterAll(): Unit = {
      spark.stop()
    }

    test("Continuity break check with Different Scenarios") {

      val actualDF=workerContinuityLogicTest.calculateWorkerContinuity(sourceDF)
//      actualDF.show()


      val expectedList=List(("W1",3),("W2",2),("W3",1),("W4",1),("W5",3),("W6",2),("W7",1),("W8",1))
      val expectedDF=spark.createDataFrame(expectedList).toDF(Constants.COL_WORKER,Constants.COL_CONTINUITY)
//      expectedDF.show()

//      actualDF.except(expectedDF).show()

      assert(actualDF.except(expectedDF).count()==0, "Some scenarios are failing")
    }

}
