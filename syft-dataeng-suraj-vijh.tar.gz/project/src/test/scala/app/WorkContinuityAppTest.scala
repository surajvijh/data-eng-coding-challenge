package com.company.app

import org.apache.spark.sql.SparkSession
import org.scalatest.{BeforeAndAfterAll, FunSuite}
import com.company.app.WorkContinuityApp.readFile
import com.company.core.SparkUtil

class WorkContinuityAppTest extends FunSuite with BeforeAndAfterAll{

  @transient var spark: SparkSession = _

  override def beforeAll(): Unit = {
    spark = SparkUtil.getSparkSession("local")
  }

  override def afterAll(): Unit = {
    spark.stop()
  }

  test("Data File Loading") {
    val sparkDF=readFile(spark,"data")
    val rCount = sparkDF.count()
    assert(rCount==10001, " record count should be 10001")
  }

}
