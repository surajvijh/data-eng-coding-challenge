package com.company.app

import com.company.core.SparkUtil
import org.apache.log4j.Logger
import com.company.logic.WorkerContinuityCalculatorLogic
import org.apache.spark.sql.{DataFrame, SparkSession}
import com.company.entity.SourceSchemaStruct

object WorkContinuityApp extends Serializable  {

  def main(args: Array[String]): Unit = {

    @transient lazy val logger: Logger = Logger.getLogger(getClass.getName)
    val spark=SparkUtil.getSparkSession("local[3]")

    logger.info("args length: "+args.length.toString)
    val (inputPath,outputPath)=args.length match {
      case 2=>(args(0),args(1))
      case _=>("data","output/result")
    }

    logger.info("inputPath: "+inputPath)
    logger.info("outputPath: "+outputPath)


    val sourceDF: DataFrame = readFile(spark,inputPath)


    val workerContinuityCalculatorLogic:WorkerContinuityCalculatorLogic=new WorkerContinuityCalculatorLogic
    val targetDF: DataFrame = workerContinuityCalculatorLogic.calculateWorkerContinuity(sourceDF)

//    targetDF.show()
    writeFile(targetDF, outputPath)
    spark.stop()

  }

// read file using spark
   def readFile(spark: SparkSession, inputPath: String): DataFrame = {
    spark.read.format("csv").schema(SourceSchemaStruct.schema)
      .load(inputPath)
  }

// Writing data to file
  private def writeFile(targetDF: DataFrame, outputPath: String) = {
    targetDF.coalesce(1).write.format("csv").mode("overwrite").option("path", outputPath).save()
  }


}
