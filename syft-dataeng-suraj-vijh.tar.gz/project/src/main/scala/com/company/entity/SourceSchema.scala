package com.company.entity

case class SourceSchema(worker:String, employer: String, role: String, date:String )
