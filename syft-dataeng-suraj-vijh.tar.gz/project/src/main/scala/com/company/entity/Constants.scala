package com.company.entity

object Constants {

  val COL_EMPLOYER: String="Employer"
  val COL_WORKER: String="Worker"
  val COL_WORKER_RNM="worker_renamed"
  val COL_ROLE="Role"
  val COL_DATE: String="Date"
  val COL_DATE_DIFF="date_diff"
  val COL_ROW_NUM="row_num"
  val COL_MIN_ROW_NUM="min_row_num"
  val COL_STATUS="status"
  val COL_CONTINUITY="Continuity"
  val COL_WORKER_EMP_ROLE_DTL="worker_employer_role_dtl"
  val COL_LEAD_WORKER_EMP_ROLE_DTL="lead_worker_employer_role_dtl"

  val VALUE_VALID="VALID"
  val VALUE_INVALID="INVALID"

  val DATE_FORMAT="yyyy-MM-dd HH:mm:ss"


}
