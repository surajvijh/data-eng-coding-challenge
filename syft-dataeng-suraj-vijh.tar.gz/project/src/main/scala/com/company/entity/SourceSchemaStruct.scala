package com.company.entity

import org.apache.spark.sql.types.{DateType, StringType, StructField, StructType,TimestampType}

object SourceSchemaStruct {

  val schema=StructType(List(StructField("Worker",StringType),
    StructField("Employer",StringType),
    StructField("Role",StringType),
    StructField("Date",StringType)))
}


