package com.company.core

import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession


object SparkUtil{

  @transient var spark:SparkSession=_

  def getSparkSession(master: String): SparkSession={
    val conf: SparkConf=new SparkConf()
    if (master != "")   conf.setMaster(master)
    conf.set("spark.sql.shuffle.partitions","1")
    spark=SparkSession.builder().config(conf).getOrCreate()
    spark
  }

}
