package com.company.logic

import com.company.entity.Constants
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StringType
//import org.apache.spark.storage.StorageLevel

class WorkerContinuityCalculatorLogic extends Serializable {

  def calculateWorkerContinuity(sourceDF: DataFrame) = {

//  Converted date column data type from string to timestamp
//  Created another column with concatenation of Worker, Employer and role. To compare later, if worker has changed job or not.
    val transformDF=sourceDF.withColumn(Constants.COL_DATE,to_timestamp(col(Constants.COL_DATE),Constants.DATE_FORMAT))
      .withColumn(Constants.COL_WORKER_EMP_ROLE_DTL,concat(col(Constants.COL_WORKER).cast(StringType),lit("|")
        ,col(Constants.COL_EMPLOYER).cast(StringType),lit("|"),col(Constants.COL_ROLE).cast(StringType)))



//    Window funtion on partition worker and date desc. To compare later, if worker has changed job or not.
    val windowPartitionPerWorkerAndDate = Window.partitionBy(Constants.COL_WORKER).orderBy(col(Constants.COL_DATE).desc)


// Evaluate row_num based on window function. To Fetch latest record for all the workers
    val transformWindowDF = transformDF.withColumn(Constants.COL_ROW_NUM, row_number().over(windowPartitionPerWorkerAndDate))

// In case of huge dataset, its better to persist the dataframe
//    Disable caching for now
//    transformWindowDF.persist(StorageLevel.MEMORY_AND_DISK)


//    Compare Worker, Employer and role details of one transaction with the next transaction, to identify worker changed job  or not.
//    Identify the minimum row num, where Worker changed job.
      val lastContinuityRecordPerWorkerDF=transformWindowDF.withColumn(Constants.COL_LEAD_WORKER_EMP_ROLE_DTL,lead(col(Constants.COL_WORKER_EMP_ROLE_DTL),1).over(windowPartitionPerWorkerAndDate))
      .filter(col(Constants.COL_WORKER_EMP_ROLE_DTL)=!=col(Constants.COL_LEAD_WORKER_EMP_ROLE_DTL))
      .groupBy(Constants.COL_WORKER).agg(min(Constants.COL_ROW_NUM).alias(Constants.COL_MIN_ROW_NUM))
        .withColumnRenamed(Constants.COL_WORKER,Constants.COL_WORKER_RNM)
        .select(Constants.COL_WORKER_RNM,Constants.COL_MIN_ROW_NUM)

// Using min row num identify, whether worker changed the job or not.
    val workerDtlWithSameJobDF=transformWindowDF.join(lastContinuityRecordPerWorkerDF,col(Constants.COL_WORKER)===col(Constants.COL_WORKER_RNM),"left")
      .filter(col(Constants.COL_ROW_NUM)<=when(col(Constants.COL_MIN_ROW_NUM).isNull,lit(Integer.MAX_VALUE)).otherwise(col(Constants.COL_MIN_ROW_NUM))).drop("worker2",Constants.COL_MIN_ROW_NUM)


//    Window funtion on partition worker,employer,role and date desc. To compare later, if worker had a break in between or not.
    val windowPartitionPerWorkerEmpRole = Window.partitionBy(Constants.COL_EMPLOYER, Constants.COL_WORKER,
      Constants.COL_ROLE).orderBy(col(Constants.COL_DATE).desc)

// Calculate date difference grouping 3 key columns for each record
    val calculateDateDiffPerWorkerDF = workerDtlWithSameJobDF.withColumn(Constants.COL_DATE_DIFF,
      datediff(lag(col(Constants.COL_DATE), 1).over(windowPartitionPerWorkerEmpRole), col(Constants.COL_DATE)))
      .withColumn(Constants.COL_ROW_NUM, row_number().over(windowPartitionPerWorkerEmpRole))

    val refactoredDateDiffPerWorkerDF = calculateDateDiffPerWorkerDF.withColumn(Constants.COL_DATE_DIFF, when(col(Constants.COL_DATE_DIFF).isNull, lit(1)).otherwise(col(Constants.COL_DATE_DIFF)))


//   Evaluate status column to identify continuity. Valid when date diff<=6, otherwise invalid
    val evaluateStatusPerWorkerDF = refactoredDateDiffPerWorkerDF.withColumn(Constants.COL_STATUS, when(col(Constants.COL_DATE_DIFF) <= 6 || col(Constants.COL_ROW_NUM) === 1, lit(s"${Constants.VALUE_VALID}"))
      .otherwise(lit(s"${Constants.VALUE_INVALID}")))


//    Using invalid status, evaluate min row num
    val evaluateInvalidStatusRowNumDF = evaluateStatusPerWorkerDF.filter(s"${Constants.COL_STATUS}='${Constants.VALUE_INVALID}'").groupBy(Constants.COL_WORKER, Constants.COL_EMPLOYER, Constants.COL_ROLE)
      .agg(min(Constants.COL_ROW_NUM).alias(Constants.COL_MIN_ROW_NUM))


//    Using min row num of invalid, finding the max row_num for valid records which will be value of Continuity
    val calculateContinuityPerWorkerDF = evaluateStatusPerWorkerDF.filter(s"${Constants.COL_STATUS}='${Constants.VALUE_VALID}'").join(evaluateInvalidStatusRowNumDF, Seq(Constants.COL_WORKER, Constants.COL_EMPLOYER,
      Constants.COL_ROLE), "left")
      .withColumn(Constants.COL_MIN_ROW_NUM, when(col(Constants.COL_MIN_ROW_NUM).isNull, Integer.MAX_VALUE).otherwise(col(Constants.COL_MIN_ROW_NUM)))
      .filter(s"${Constants.COL_ROW_NUM}<${Constants.COL_MIN_ROW_NUM}").groupBy(Constants.COL_WORKER).agg(max(Constants.COL_ROW_NUM).alias(Constants.COL_CONTINUITY))
//    calculateContinuityDF.show()
    calculateContinuityPerWorkerDF
  }

}
