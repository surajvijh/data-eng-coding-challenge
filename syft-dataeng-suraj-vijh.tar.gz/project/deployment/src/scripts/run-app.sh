#!/bin/bash
set -e

env=$1
if [ -z $env ]
then
env=dev
fi

envConfig_path="../envconfigs"
propertyFile="../envconfigs/${env}/spark-submit.properties"

if [[ ! -f ${propertyFile} ]]; then
    echo "Error: please check environment as first parameter!"
    exit 1
else
    source ${propertyFile}
fi

echo "executableJarPath: $executableJarPath"


echo "Starting $appName for $env in local mode"
spark-submit \
--name "$appName" \
--master local \
--conf spark.driver.extraJavaOptions="-Dlog4j.configuration=file:$envConfig_path/$env/log4j.properties" \
--conf spark.executor.extraJavaOptions="-Dlog4j.configuration=file:$envConfig_path/$env/log4j.properties" \
--class com.company.app.WorkContinuityApp \
--files $envConfig_path/$env/log4j.properties \
--verbose $executableJarPath ../data ../output/result

mv ../output/result/*.csv ../result.csv
rm -rf ../output/result

#spark-submit --name sv --master local --class com.company.app.WorkContinuityApp --verbose ../jars/project-0.1-SNAPSHOT.jar


